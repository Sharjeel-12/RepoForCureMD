﻿using Assignment_03.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_03.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class OrderManager : IOrderRepository
    {
        public static List<Order> orders = new List<Order>();

        public Task<Order> GetByIdAsync(string id)
        {
            var filtered = orders.Where(order => order.Order_ID == id).ToList();
            if (filtered.Count == 0)
            {
                Console.WriteLine("No order has been placed yet");
                return null;
            }
            return  Task.FromResult(filtered[0]);
        }

        public  Task<IEnumerable<Order>> GetAllAsync()
        {
            if (orders.Count == 0)
            {
                Console.WriteLine("No order has been placed yet");
            }
            return Task.FromResult(orders.AsEnumerable());
        }

        public  Task AddAsync(Order order)
        {
            orders.Add(order);
            return Task.CompletedTask;
        }

        public Task UpdateAsync(Order order)
        {
            var existingOrder = orders.FirstOrDefault(o => o.Order_ID == order.Order_ID);
            if (existingOrder != null)
            {
                Console.WriteLine("Enter the new Order details : -");
                Console.Write("New Order ID: ");
                existingOrder.Order_ID = Console.ReadLine();

                Console.Write("New Customer ID: ");
                existingOrder.CustomerID = Console.ReadLine();

                existingOrder.DateTimeStamp = DateTime.Now;
            }
            else
            {
                Console.WriteLine("Order not found!");
            }
            return Task.CompletedTask;
        }

        public  Task DeleteAsync(string id)
        {
            var filtered = orders.Where(order => order.Order_ID == id).ToList();

            if (filtered.Count == 0)
            {
                Console.WriteLine("No such record found!");
            }
            else
            {
                orders.Remove(filtered[0]);
            }
            return Task.CompletedTask;
        }

        public List<Order> GetOrdersByCustomer(string customerId)
        {
            var filtered = orders.Where(order => order.CustomerID == customerId).ToList();
            if (filtered.Count == 0)
            {
                Console.WriteLine("No such record found!");
            }
            return filtered;
        }

        public List<Order> GetOrdersByDateRange(DateTime start, DateTime end)
        {
            var filtered = orders.Where(order => order.DateTimeStamp >= start && order.DateTimeStamp <= end).ToList();
            if (filtered.Count == 0)
            {
                Console.WriteLine("No such record found!");
            }
            return filtered;
        }
    }


}
