using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public interface IPatientRepository
    {
        Task<IEnumerable<Patient>> GetAllAsync();
        Task<Patient?> GetByIdAsync(int id);
        Task<IEnumerable<Patient>> GetByEmailAsync(string email);
        Task<int> CreateAsync(Patient p);
        Task<int> UpdateAsync(Patient p);
        Task<int> DeleteAsync(int id);
    }
}