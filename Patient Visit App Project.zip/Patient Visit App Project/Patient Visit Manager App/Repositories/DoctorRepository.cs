using System.Data.SqlClient;
using Patient_Visit_Manager_App.Data;
using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public class DoctorRepository : IDoctorRepository
    {
        private readonly IRepoInterface _db;
        public DoctorRepository(IRepoInterface db) => _db = db;

        public async Task<IEnumerable<Doctor>> GetAllAsync()
        {
            var cmd = await _db.createCommand("SELECT * FROM doctors");
            return await _db.ExecuteDoctorReadCommand(cmd);
        }

        public async Task<Doctor?> GetByIdAsync(int id)
        {
            var cmd = await _db.createCommand("SELECT * FROM doctors WHERE doctorID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            var list = await _db.ExecuteDoctorReadCommand(cmd);
            return list.FirstOrDefault();
        }

        public async Task<IEnumerable<Doctor>> GetByEmailAsync(string email)
        {
            var cmd = await _db.createCommand("SELECT * FROM doctors WHERE doctorEmail=@e");
            cmd.Parameters.AddWithValue("@e", email);
            return await _db.ExecuteDoctorReadCommand(cmd);
        }

        public async Task<IEnumerable<Doctor>> GetBySpecializationAsync(string specialization)
        {
            var cmd = await _db.createCommand("SELECT * FROM doctors WHERE specialization=@s");
            cmd.Parameters.AddWithValue("@s", specialization);
            return await _db.ExecuteDoctorReadCommand(cmd);
        }

        public async Task<int> CreateAsync(Doctor d)
        {
            var cmd = await _db.createCommand(@"INSERT INTO doctors(doctorID,visitID,doctorName,doctorEmail,doctorPhone,specialization)
                                               VALUES(@id,@vid,@name,@email,@phone,@spec)");
            cmd.Parameters.AddWithValue("@id", d.Id);
            cmd.Parameters.AddWithValue("@vid", d.VisitID);
            cmd.Parameters.AddWithValue("@name", d.Name);
            cmd.Parameters.AddWithValue("@email", d.Email ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@phone", d.Phone ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@spec", d.Specialization ?? (object)DBNull.Value);
            await _db.ExecuteWriteCommand(cmd);
            return d.Id;
        }

        public async Task<int> UpdateAsync(Doctor d)
        {
            var cmd = await _db.createCommand(@"UPDATE doctors SET visitID=@vid, doctorName=@name, doctorEmail=@email, doctorPhone=@phone, specialization=@spec
                                               WHERE doctorID=@id");
            cmd.Parameters.AddWithValue("@id", d.Id);
            cmd.Parameters.AddWithValue("@vid", d.VisitID);
            cmd.Parameters.AddWithValue("@name", d.Name);
            cmd.Parameters.AddWithValue("@email", d.Email ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@phone", d.Phone ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@spec", d.Specialization ?? (object)DBNull.Value);
            await _db.ExecuteWriteCommand(cmd);
            return d.Id;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var cmd = await _db.createCommand("DELETE FROM doctors WHERE doctorID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            await _db.ExecuteWriteCommand(cmd);
            return id;
        }
    }
}