using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public interface IDoctorRepository
    {
        Task<IEnumerable<Doctor>> GetAllAsync();
        Task<Doctor?> GetByIdAsync(int id);
        Task<IEnumerable<Doctor>> GetByEmailAsync(string email);
        Task<IEnumerable<Doctor>> GetBySpecializationAsync(string specialization);
        Task<int> CreateAsync(Doctor d);
        Task<int> UpdateAsync(Doctor d);
        Task<int> DeleteAsync(int id);
    }
}