using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public interface IVisitRepository
    {
        Task<IEnumerable<Visit>> GetAllAsync();
        Task<Visit?> GetByIdAsync(int id);
        Task<IEnumerable<Visit>> GetByDateAsync(DateOnly date);
        Task<int> CreateAsync(Visit v);
        Task<int> UpdateAsync(Visit v);
        Task<int> DeleteAsync(int id);
    }
}