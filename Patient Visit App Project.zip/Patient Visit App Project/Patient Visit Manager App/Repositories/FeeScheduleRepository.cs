using System.Data;
using Patient_Visit_Manager_App.Data;
using System.Data.SqlClient;

namespace Patient_Visit_Manager_App.Repositories
{
    public class FeeScheduleRepository : IFeeScheduleRepository
    {
        private readonly IRepoInterface _db;
        public FeeScheduleRepository(IRepoInterface db) => _db = db;

        public async Task<IEnumerable<(int feeID,string VisitType, decimal feePerMinute)>> GetAllAsync()
        {
            var list = new List<(int,string,decimal)>();
            var cmd = await _db.createCommand("SELECT feeID, VisitType, feePerMinute FROM feeSchedule");
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            while (await rdr.ReadAsync())
            {
                list.Add((rdr.GetInt32(0), rdr.GetString(1), rdr.GetDecimal(2)));
            }
            return list;
        }

        public async Task<decimal?> GetFeePerMinuteByTypeAsync(string visitType)
        {
            var cmd = await _db.createCommand("SELECT feePerMinute FROM feeSchedule WHERE VisitType=@t");
            cmd.Parameters.AddWithValue("@t", visitType);
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            var result = await cmd.ExecuteScalarAsync();
            return result == null || result == DBNull.Value ? null : (decimal?)Convert.ToDecimal(result);
        }
    }
}