using Patient_Visit_Manager_App.Data;
using System.Data.SqlClient;

namespace Patient_Visit_Manager_App.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IRepoInterface _db;
        public AuthRepository(IRepoInterface db) => _db = db;

        public async Task<int> RegisterAsync(string email, string password, string role)
        {
            // Ensure tables exist (idempotent)
            using (var conn = await _db.createConnectionAsync())
            {
                var ensure = new SqlCommand(@"
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='users')
BEGIN
  CREATE TABLE users(
    userId INT IDENTITY(1,1) PRIMARY KEY,
    email VARCHAR(200) UNIQUE NOT NULL,
    passwordHash VARCHAR(200) NOT NULL,
    role VARCHAR(50) NOT NULL
  )
END", conn);
                await ensure.ExecuteNonQueryAsync();
            }

            var cmd = await _db.createCommand("INSERT INTO users(email,passwordHash,role) VALUES(@e,@p,@r); SELECT SCOPE_IDENTITY();");
            cmd.Parameters.AddWithValue("@e", email);
            cmd.Parameters.AddWithValue("@p", password); // plaintext for simplicity as requested
            cmd.Parameters.AddWithValue("@r", role);
            using var conn2 = await _db.createConnectionAsync();
            cmd.Connection = conn2;
            var idObj = await cmd.ExecuteScalarAsync();
            return Convert.ToInt32(idObj);
        }

        public async Task<AppUser?> LoginAsync(string email, string password)
        {
            var cmd = await _db.createCommand("SELECT userId,email,role FROM users WHERE email=@e AND passwordHash=@p");
            cmd.Parameters.AddWithValue("@e", email);
            cmd.Parameters.AddWithValue("@p", password);
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            if (await rdr.ReadAsync())
            {
                return new AppUser(rdr.GetInt32(0), rdr.GetString(1), rdr.GetString(2));
            }
            return null;
        }
    }
}