using System.Data;
using System.Data.SqlClient;
using Patient_Visit_Manager_App.Data;
using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public class VisitRepository : IVisitRepository
    {
        private readonly IRepoInterface _db;
        public VisitRepository(IRepoInterface db) => _db = db;

        private static Visit Map(IDataRecord r) => new Visit
        {
            Id = r.GetInt32(r.GetOrdinal("visitID")),
            Type = r.IsDBNull(r.GetOrdinal("visitType")) ? "" : r.GetString(r.GetOrdinal("visitType")),
            Duration = r.IsDBNull(r.GetOrdinal("visitDuration")) ? 0 : r.GetInt32(r.GetOrdinal("visitDuration")),
            Date = DateOnly.FromDateTime(r.GetDateTime(r.GetOrdinal("visitDate"))),
            Time = TimeOnly.FromTimeSpan((TimeSpan)r["visitTime"]),
            Fee = Convert.ToDouble(r["visitFee"])
        };

        public async Task<IEnumerable<Visit>> GetAllAsync()
        {
            var list = new List<Visit>();
            var cmd = await _db.createCommand("SELECT * FROM visits");
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            while (await rdr.ReadAsync()) list.Add(Map(rdr));
            return list;
        }

        public async Task<Visit?> GetByIdAsync(int id)
        {
            var cmd = await _db.createCommand("SELECT * FROM visits WHERE visitID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            if (await rdr.ReadAsync()) return Map(rdr);
            return null;
        }

        public async Task<IEnumerable<Visit>> GetByDateAsync(DateOnly date)
        {
            var list = new List<Visit>();
            var cmd = await _db.createCommand("SELECT * FROM visits WHERE visitDate=@d");
            cmd.Parameters.AddWithValue("@d", date.ToDateTime(TimeOnly.MinValue));
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            while (await rdr.ReadAsync()) list.Add(Map(rdr));
            return list;
        }

        public async Task<int> CreateAsync(Visit v)
        {
            var cmd = await _db.createCommand(@"INSERT INTO visits(visitID,visitType,VisittypeID,visitDuration,visitDate,visitTime,visitFee)
                                               VALUES(@id,@type,@typeId,@dur,@date,@time,@fee)");
            cmd.Parameters.AddWithValue("@id", v.Id);
            cmd.Parameters.AddWithValue("@type", v.Type ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@typeId", DBNull.Value);
            cmd.Parameters.AddWithValue("@dur", v.Duration);
            cmd.Parameters.AddWithValue("@date", v.Date.ToDateTime(TimeOnly.MinValue));
            cmd.Parameters.AddWithValue("@time", v.Time.ToTimeSpan());
            cmd.Parameters.AddWithValue("@fee", v.Fee);
            await _db.ExecuteWriteCommand(cmd);
            return v.Id;
        }

        public async Task<int> UpdateAsync(Visit v)
        {
            var cmd = await _db.createCommand(@"UPDATE visits SET visitType=@type, visitDuration=@dur, visitDate=@date, visitTime=@time, visitFee=@fee
                                               WHERE visitID=@id");
            cmd.Parameters.AddWithValue("@id", v.Id);
            cmd.Parameters.AddWithValue("@type", v.Type ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@dur", v.Duration);
            cmd.Parameters.AddWithValue("@date", v.Date.ToDateTime(TimeOnly.MinValue));
            cmd.Parameters.AddWithValue("@time", v.Time.ToTimeSpan());
            cmd.Parameters.AddWithValue("@fee", v.Fee);
            await _db.ExecuteWriteCommand(cmd);
            return v.Id;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var cmd = await _db.createCommand("DELETE FROM visits WHERE visitID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            await _db.ExecuteWriteCommand(cmd);
            return id;
        }
    }
}