namespace Patient_Visit_Manager_App.Repositories
{
    public interface ILoggerRepository
    {
        Task<IEnumerable<(int ActivityID,string Description,int LoggerID, DateOnly Date, TimeOnly Time)>> GetActivitiesAsync();
    }
}