using Patient_Visit_Manager_App.Data;
using System.Data.SqlClient;

namespace Patient_Visit_Manager_App.Repositories
{
    public class LoggerRepository : ILoggerRepository
    {
        private readonly IRepoInterface _db;
        public LoggerRepository(IRepoInterface db) => _db = db;

        public async Task<IEnumerable<(int ActivityID,string Description,int LoggerID, DateOnly Date, TimeOnly Time)>> GetActivitiesAsync()
        {
            var list = new List<(int,string,int,DateOnly,TimeOnly)>();
            var cmd = await _db.createCommand("SELECT ActivityID, activityDescription, loggerID, ActivityDate, ActivityTime FROM loggerActivities");
            using var conn = await _db.createConnectionAsync();
            cmd.Connection = conn;
            using var rdr = await cmd.ExecuteReaderAsync();
            while (await rdr.ReadAsync())
            {
                list.Add((rdr.GetInt32(0), rdr.GetString(1), rdr.GetInt32(2),
                          DateOnly.FromDateTime(rdr.GetDateTime(3)), TimeOnly.FromTimeSpan((TimeSpan)rdr["ActivityTime"])));
            }
            return list;
        }
    }
}