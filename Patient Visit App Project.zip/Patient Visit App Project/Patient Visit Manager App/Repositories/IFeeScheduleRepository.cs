namespace Patient_Visit_Manager_App.Repositories
{
    public interface IFeeScheduleRepository
    {
        Task<IEnumerable<(int feeID,string VisitType, decimal feePerMinute)>> GetAllAsync();
        Task<decimal?> GetFeePerMinuteByTypeAsync(string visitType);
    }
}