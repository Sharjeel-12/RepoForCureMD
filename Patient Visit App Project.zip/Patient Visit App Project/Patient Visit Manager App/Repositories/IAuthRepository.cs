namespace Patient_Visit_Manager_App.Repositories
{
    public record AppUser(int UserId, string Email, string Role);
    public interface IAuthRepository
    {
        Task<int> RegisterAsync(string email, string password, string role);
        Task<AppUser?> LoginAsync(string email, string password);
    }
}