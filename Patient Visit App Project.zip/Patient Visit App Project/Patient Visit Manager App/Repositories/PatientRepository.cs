using System.Data.SqlClient;
using Patient_Visit_Manager_App.Data;
using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Repositories
{
    public class PatientRepository : IPatientRepository
    {
        private readonly IRepoInterface _db;
        public PatientRepository(IRepoInterface db) => _db = db;

        public async Task<IEnumerable<Patient>> GetAllAsync()
        {
            var cmd = await _db.createCommand("SELECT * FROM patients");
            return await _db.ExecutePatientReadCommand(cmd);
        }

        public async Task<Patient?> GetByIdAsync(int id)
        {
            var cmd = await _db.createCommand("SELECT * FROM patients WHERE patientID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            var list = await _db.ExecutePatientReadCommand(cmd);
            return list.FirstOrDefault();
        }

        public async Task<IEnumerable<Patient>> GetByEmailAsync(string email)
        {
            var cmd = await _db.createCommand("SELECT * FROM patients WHERE patientEmail=@e");
            cmd.Parameters.AddWithValue("@e", email);
            return await _db.ExecutePatientReadCommand(cmd);
        }

        public async Task<int> CreateAsync(Patient p)
        {
            var cmd = await _db.createCommand(@"INSERT INTO patients(patientID,visitID,patientName,patientEmail,patientPhone,patientDescription)
                                               VALUES(@pid,@vid,@name,@email,@phone,@desc)");
            cmd.Parameters.AddWithValue("@pid", p.PatientID);
            cmd.Parameters.AddWithValue("@vid", p.VisitID);
            cmd.Parameters.AddWithValue("@name", p.Name);
            cmd.Parameters.AddWithValue("@email", p.PatientEmail ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@phone", DBNull.Value);
            cmd.Parameters.AddWithValue("@desc", p.Description ?? (object)DBNull.Value);
            await _db.ExecuteWriteCommand(cmd);
            return p.PatientID;
        }

        public async Task<int> UpdateAsync(Patient p)
        {
            var cmd = await _db.createCommand(@"UPDATE patients SET visitID=@vid, patientName=@name, patientEmail=@email, patientDescription=@desc
                                               WHERE patientID=@pid");
            cmd.Parameters.AddWithValue("@pid", p.PatientID);
            cmd.Parameters.AddWithValue("@vid", p.VisitID);
            cmd.Parameters.AddWithValue("@name", p.Name);
            cmd.Parameters.AddWithValue("@email", p.PatientEmail ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@desc", p.Description ?? (object)DBNull.Value);
            await _db.ExecuteWriteCommand(cmd);
            return p.PatientID;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var cmd = await _db.createCommand("DELETE FROM patients WHERE patientID=@id");
            cmd.Parameters.AddWithValue("@id", id);
            await _db.ExecuteWriteCommand(cmd);
            return id;
        }
    }
}