using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Services
{
    public interface IAdminInterface
    {
        Task<IEnumerable<Patient>> GetPatientsAsync();
        Task<Patient?> GetPatientAsync(int id);
        Task<int> AddPatientAsync(Patient patient);
        Task<int> UpdatePatientAsync(Patient patient);
        Task<int> DeletePatientAsync(int id);

        Task<IEnumerable<Doctor>> GetDoctorsAsync();
        Task<Doctor?> GetDoctorAsync(int id);
        Task<int> AddDoctorAsync(Doctor doctor);
        Task<int> UpdateDoctorAsync(Doctor doctor);
        Task<int> DeleteDoctorAsync(int id);

        Task<IEnumerable<Visit>> GetVisitsAsync();
        Task<Visit?> GetVisitAsync(int id);
        Task<int> AddVisitAsync(Visit visit);
        Task<int> UpdateVisitAsync(Visit visit);
        Task<int> DeleteVisitAsync(int id);
    }
}