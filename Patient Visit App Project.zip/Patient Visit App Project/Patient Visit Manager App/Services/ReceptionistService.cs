using Patient_Visit_Manager_App.Models;
using Patient_Visit_Manager_App.Repositories;

namespace Patient_Visit_Manager_App.Services
{
    public class ReceptionistService : IReceptionistInterface
    {
        private readonly IPatientRepository _patients;
        private readonly IVisitRepository _visits;

        public ReceptionistService(IPatientRepository p, IVisitRepository v)
        {
            _patients = p; _visits = v;
        }

        public Task<IEnumerable<Patient>> GetPatientsAsync() => _patients.GetAllAsync();
        public Task<Patient?> GetPatientAsync(int id) => _patients.GetByIdAsync(id);
        public Task<int> AddPatientAsync(Patient patient) => _patients.CreateAsync(patient);
        public Task<int> UpdatePatientAsync(Patient patient) => _patients.UpdateAsync(patient);

        public Task<IEnumerable<Visit>> GetVisitsAsync() => _visits.GetAllAsync();
        public Task<Visit?> GetVisitAsync(int id) => _visits.GetByIdAsync(id);
        public Task<int> AddVisitAsync(Visit visit) => _visits.CreateAsync(visit);
        public Task<int> UpdateVisitAsync(Visit visit) => _visits.UpdateAsync(visit);
    }
}