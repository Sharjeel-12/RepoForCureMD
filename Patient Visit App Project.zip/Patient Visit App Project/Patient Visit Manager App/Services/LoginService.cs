using Patient_Visit_Manager_App.Repositories;

namespace Patient_Visit_Manager_App.Services
{
    public class LoginService : ILoginServiceInterface
    {
        private readonly IAuthRepository _auth;
        public LoginService(IAuthRepository a) { _auth = a; }

        public async Task<(bool Success, string? Role, string? Error)> LoginAsync(string email, string password)
        {
            var user = await _auth.LoginAsync(email, password);
            if (user is null) return (false, null, "Invalid email or password");
            return (true, user.Role, null);
        }

        public Task<int> RegisterAsync(string email, string password, string role)
            => _auth.RegisterAsync(email, password, role);
    }
}