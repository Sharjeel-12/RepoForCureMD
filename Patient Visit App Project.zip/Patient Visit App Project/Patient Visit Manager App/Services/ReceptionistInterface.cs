using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.Services
{
    public interface IReceptionistInterface
    {
        Task<IEnumerable<Patient>> GetPatientsAsync();
        Task<Patient?> GetPatientAsync(int id);
        Task<int> AddPatientAsync(Patient patient);
        Task<int> UpdatePatientAsync(Patient patient);

        Task<IEnumerable<Visit>> GetVisitsAsync();
        Task<Visit?> GetVisitAsync(int id);
        Task<int> AddVisitAsync(Visit visit);
        Task<int> UpdateVisitAsync(Visit visit);
    }
}