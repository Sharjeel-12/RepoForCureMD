namespace Patient_Visit_Manager_App.Services
{
    public interface ILoginServiceInterface
    {
        Task<(bool Success,string? Role,string? Error)> LoginAsync(string email, string password);
        Task<int> RegisterAsync(string email, string password, string role);
    }
}