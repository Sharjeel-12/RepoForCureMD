using Patient_Visit_Manager_App.Models;
using Patient_Visit_Manager_App.Repositories;

namespace Patient_Visit_Manager_App.Services
{
    public class AdminService : IAdminInterface
    {
        private readonly IPatientRepository _patients;
        private readonly IDoctorRepository _doctors;
        private readonly IVisitRepository _visits;

        public AdminService(IPatientRepository p, IDoctorRepository d, IVisitRepository v)
        {
            _patients = p; _doctors = d; _visits = v;
        }

        public Task<IEnumerable<Patient>> GetPatientsAsync() => _patients.GetAllAsync();
        public Task<Patient?> GetPatientAsync(int id) => _patients.GetByIdAsync(id);
        public Task<int> AddPatientAsync(Patient patient) => _patients.CreateAsync(patient);
        public Task<int> UpdatePatientAsync(Patient patient) => _patients.UpdateAsync(patient);
        public Task<int> DeletePatientAsync(int id) => _patients.DeleteAsync(id);

        public Task<IEnumerable<Doctor>> GetDoctorsAsync() => _doctors.GetAllAsync();
        public Task<Doctor?> GetDoctorAsync(int id) => _doctors.GetByIdAsync(id);
        public Task<int> AddDoctorAsync(Doctor doctor) => _doctors.CreateAsync(doctor);
        public Task<int> UpdateDoctorAsync(Doctor doctor) => _doctors.UpdateAsync(doctor);
        public Task<int> DeleteDoctorAsync(int id) => _doctors.DeleteAsync(id);

        public Task<IEnumerable<Visit>> GetVisitsAsync() => _visits.GetAllAsync();
        public Task<Visit?> GetVisitAsync(int id) => _visits.GetByIdAsync(id);
        public Task<int> AddVisitAsync(Visit visit) => _visits.CreateAsync(visit);
        public Task<int> UpdateVisitAsync(Visit visit) => _visits.UpdateAsync(visit);
        public Task<int> DeleteVisitAsync(int id) => _visits.DeleteAsync(id);
    }
}