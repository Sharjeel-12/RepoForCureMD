using Patient_Visit_Manager_App.Data;
using Patient_Visit_Manager_App.Repositories;
using Patient_Visit_Manager_App.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DI: DB + Repos + Services
var cs = builder.Configuration.GetConnectionString("DefaultConnection")!;
builder.Services.AddSingleton<IRepoInterface>(sp => new SQL_DB(cs));

builder.Services.AddScoped<IPatientRepository, PatientRepository>();
builder.Services.AddScoped<IDoctorRepository, DoctorRepository>();
builder.Services.AddScoped<IVisitRepository, VisitRepository>();
builder.Services.AddScoped<IFeeScheduleRepository, FeeScheduleRepository>();
builder.Services.AddScoped<ILoggerRepository, LoggerRepository>();
builder.Services.AddScoped<IAuthRepository, AuthRepository>();

builder.Services.AddScoped<IAdminInterface, AdminService>();
builder.Services.AddScoped<IReceptionistInterface, ReceptionistService>();
builder.Services.AddScoped<ILoginServiceInterface, LoginService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthorization();
app.MapControllers();
app.Run();