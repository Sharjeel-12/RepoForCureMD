# Patient Visit Manager Web API

This project implements a .NET 7 Web API for managing Patients, Doctors, Visits, Fee Schedules, Activity Logs, and a simple email/password login for **Admin** and **Receptionist**.

## Quick start

1. Copy `appsettings.json` connection string to point to your SQL Server and the `MuhammadSharjeelFarzadDB` database.
2. Run the SQL from your message to create the schema. For login, the API will auto-create a simple `users` table on first register.
3. Build & run:

```bash
dotnet build
dotnet run --project "Patient Visit Manager App/Patient Visit Manager App.csproj"
```

Swagger UI will be available at `/swagger`.

## Endpoints

- `POST /api/auth/register` — body: `{ email, password, role: "Admin"|"Receptionist" }`
- `POST /api/auth/login` — body: `{ email, password }`
- `GET /api/patients` / `GET /api/patients/{id}` / `POST /api/patients` / `PUT /api/patients/{id}` / `DELETE /api/patients/{id}`
- `GET /api/doctors` / `GET /api/doctors/{id}` / `GET /api/doctors/specialization/{spec}` / `POST` / `PUT` / `DELETE`
- `GET /api/visits` / `GET /api/visits/{id}` / `GET /api/visits/on/{yyyy-mm-dd}` / `POST` / `PUT` / `DELETE`
- `GET /api/feeschedule` / `GET /api/feeschedule/{type}`
- `GET /api/logger/activities`

## Design & Patterns

- Repository pattern for data access
- Services layer (Admin/Receptionist/Login) to enforce role responsibilities
- Dependency Injection configured in `Program.cs`
- ADO.NET via `SqlConnection` and `SqlCommand`

## Notes

- Authentication is **simple** (no JWT). Passwords are stored as plaintext per your request; for production, hash passwords.
- Visit fee calculation can be done client-side using `feeSchedule` as needed.