using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.DTOs
{
    public record CreatePatientDto(int PatientID, int VisitID, string Name, string? PatientEmail, string? Description);
    public static class PatientDtoMap
    {
        public static Patient ToModel(this CreatePatientDto dto) => new Patient
        {
            PatientID = dto.PatientID,
            VisitID = dto.VisitID,
            Name = dto.Name,
            PatientEmail = dto.PatientEmail ?? "",
            Description = dto.Description ?? ""
        };
    }
}