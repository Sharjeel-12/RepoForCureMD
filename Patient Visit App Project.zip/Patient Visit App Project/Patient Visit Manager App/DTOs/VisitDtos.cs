using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.DTOs
{
    public record CreateVisitDto(int Id, string Type, int Duration, DateOnly Date, TimeOnly Time, double Fee);
    public static class VisitDtoMap
    {
        public static Visit ToModel(this CreateVisitDto dto) => new Visit
        {
            Id = dto.Id,
            Type = dto.Type,
            Duration = dto.Duration,
            Date = dto.Date,
            Time = dto.Time,
            Fee = dto.Fee
        };
    }
}