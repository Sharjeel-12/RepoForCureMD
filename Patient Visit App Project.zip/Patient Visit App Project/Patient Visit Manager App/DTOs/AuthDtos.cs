namespace Patient_Visit_Manager_App.DTOs
{
    public record LoginRequest(string Email, string Password);
    public record LoginResponse(bool Success, string? Role, string? Error);
    public record RegisterRequest(string Email, string Password, string Role);
}