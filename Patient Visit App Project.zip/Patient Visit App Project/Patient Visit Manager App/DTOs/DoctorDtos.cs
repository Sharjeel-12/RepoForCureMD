using Patient_Visit_Manager_App.Models;

namespace Patient_Visit_Manager_App.DTOs
{
    public record CreateDoctorDto(int Id, int VisitID, string Name, string? Email, string? Phone, string? Specialization);
    public static class DoctorDtoMap
    {
        public static Doctor ToModel(this CreateDoctorDto dto) => new Doctor
        {
            Id = dto.Id,
            VisitID = dto.VisitID,
            Name = dto.Name,
            Email = dto.Email ?? "",
            Phone = dto.Phone ?? "",
            Specialization = dto.Specialization ?? ""
        };
    }
}