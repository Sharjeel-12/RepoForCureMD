using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.DTOs;
using Patient_Visit_Manager_App.Models;
using Patient_Visit_Manager_App.Repositories;
using Patient_Visit_Manager_App.Services;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VisitsController : ControllerBase
    {
        private readonly IAdminInterface _admin;
        private readonly IReceptionistInterface _recept;
        private readonly IVisitRepository _repo;
        public VisitsController(IAdminInterface admin, IReceptionistInterface recept, IVisitRepository repo)
        {
            _admin = admin; _recept = recept; _repo = repo;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Visit>>> GetAll() => Ok(await _repo.GetAllAsync());

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Visit>> GetOne(int id)
        {
            var v = await _repo.GetByIdAsync(id);
            return v is null ? NotFound() : Ok(v);
        }

        [HttpGet("on/{date}")]
        public async Task<ActionResult<IEnumerable<Visit>>> ByDate(DateOnly date) => Ok(await _repo.GetByDateAsync(date));

        [HttpPost]
        public async Task<IActionResult> Create(CreateVisitDto dto)
        {
            var id = await _recept.AddVisitAsync(dto.ToModel());
            return CreatedAtAction(nameof(GetOne), new { id = dto.Id }, new { id = dto.Id });
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, CreateVisitDto dto)
        {
            if (id != dto.Id) return BadRequest("ID mismatch");
            await _recept.UpdateVisitAsync(dto.ToModel());
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _admin.DeleteVisitAsync(id);
            return NoContent();
        }
    }
}