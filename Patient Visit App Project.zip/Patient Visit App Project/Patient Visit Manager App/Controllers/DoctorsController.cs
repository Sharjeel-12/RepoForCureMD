using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.DTOs;
using Patient_Visit_Manager_App.Models;
using Patient_Visit_Manager_App.Repositories;
using Patient_Visit_Manager_App.Services;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorsController : ControllerBase
    {
        private readonly IAdminInterface _admin;
        private readonly IDoctorRepository _repo;
        public DoctorsController(IAdminInterface admin, IDoctorRepository repo)
        {
            _admin = admin; _repo = repo;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Doctor>>> GetAll() => Ok(await _admin.GetDoctorsAsync());

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Doctor>> GetOne(int id)
        {
            var p = await _admin.GetDoctorAsync(id);
            return p is null ? NotFound() : Ok(p);
        }

        [HttpGet("specialization/{spec}")]
        public async Task<ActionResult<IEnumerable<Doctor>>> BySpec(string spec) => Ok(await _repo.GetBySpecializationAsync(spec));

        [HttpPost]
        public async Task<IActionResult> Create(CreateDoctorDto dto)
        {
            var id = await _admin.AddDoctorAsync(dto.ToModel());
            return CreatedAtAction(nameof(GetOne), new { id = dto.Id }, new { id = dto.Id });
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, CreateDoctorDto dto)
        {
            if (id != dto.Id) return BadRequest("ID mismatch");
            await _admin.UpdateDoctorAsync(dto.ToModel());
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _admin.DeleteDoctorAsync(id);
            return NoContent();
        }
    }
}