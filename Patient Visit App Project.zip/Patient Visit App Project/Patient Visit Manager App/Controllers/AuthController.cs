using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.DTOs;
using Patient_Visit_Manager_App.Services;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ILoginServiceInterface _login;
        public AuthController(ILoginServiceInterface login) { _login = login; }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest req)
        {
            if (req.Role != "Admin" && req.Role != "Receptionist")
                return BadRequest("Role must be Admin or Receptionist");
            var id = await _login.RegisterAsync(req.Email, req.Password, req.Role);
            return Created("", new { userId = id, req.Email, req.Role });
        }

        [HttpPost("login")]
        public async Task<ActionResult<LoginResponse>> Login(LoginRequest req)
        {
            var (ok, role, err) = await _login.LoginAsync(req.Email, req.Password);
            if (!ok) return Unauthorized(new LoginResponse(false, null, err));
            return Ok(new LoginResponse(true, role, null));
        }
    }
}