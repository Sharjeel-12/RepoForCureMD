using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.DTOs;
using Patient_Visit_Manager_App.Models;
using Patient_Visit_Manager_App.Services;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly IAdminInterface _admin;
        private readonly IReceptionistInterface _recept;
        public PatientsController(IAdminInterface admin, IReceptionistInterface recept)
        {
            _admin = admin; _recept = recept;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Patient>>> GetAll() => Ok(await _admin.GetPatientsAsync());

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Patient>> GetOne(int id)
        {
            var p = await _admin.GetPatientAsync(id);
            return p is null ? NotFound() : Ok(p);
            }

        [HttpPost]
        public async Task<IActionResult> Create(CreatePatientDto dto)
        {
            var id = await _recept.AddPatientAsync(dto.ToModel());
            return CreatedAtAction(nameof(GetOne), new { id = dto.PatientID }, new { id = dto.PatientID });
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, CreatePatientDto dto)
        {
            if (id != dto.PatientID) return BadRequest("ID mismatch");
            await _recept.UpdatePatientAsync(dto.ToModel());
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _admin.DeletePatientAsync(id);
            return NoContent();
        }
    }
}