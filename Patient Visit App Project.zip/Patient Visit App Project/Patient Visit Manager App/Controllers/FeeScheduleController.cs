using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.Repositories;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FeeScheduleController : ControllerBase
    {
        private readonly IFeeScheduleRepository _repo;
        public FeeScheduleController(IFeeScheduleRepository repo) { _repo = repo; }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var rows = await _repo.GetAllAsync();
            return Ok(rows);
        }

        [HttpGet("{type}")]
        public async Task<IActionResult> GetByType(string type)
        {
            var fee = await _repo.GetFeePerMinuteByTypeAsync(type);
            if (fee is null) return NotFound();
            return Ok(new { VisitType = type, FeePerMinute = fee });
        }
    }
}