using Microsoft.AspNetCore.Mvc;
using Patient_Visit_Manager_App.Repositories;

namespace Patient_Visit_Manager_App.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoggerController : ControllerBase
    {
        private readonly ILoggerRepository _repo;
        public LoggerController(ILoggerRepository repo) { _repo = repo; }

        [HttpGet("activities")]
        public async Task<IActionResult> GetActivities()
        {
            var rows = await _repo.GetActivitiesAsync();
            return Ok(rows);
        }
    }
}