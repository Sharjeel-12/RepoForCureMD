using Patient_Visit_Manager_App.Models;
using System.Data;
using System.Data.SqlClient;

namespace Patient_Visit_Manager_App.Data
{
    public class SQL_DB : IRepoInterface
    {
        private readonly string _connectionString;
        public SQL_DB(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<SqlConnection> createConnectionAsync()
        {
            var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();
            return conn;
        }

        public Task<SqlCommand> createCommand(string sql)
        {
            var cmd = new SqlCommand(sql);
            cmd.CommandType = CommandType.Text;
            return Task.FromResult(cmd);
        }

        public async Task<IEnumerable<Patient>> ExecutePatientReadCommand(SqlCommand command)
        {
            var result = new List<Patient>();
            using (var conn = await createConnectionAsync())
            {
                command.Connection = conn;
                using var rdr = await command.ExecuteReaderAsync();
                while (await rdr.ReadAsync())
                {
                    result.Add(new Patient
                    {
                        PatientID = rdr.GetInt32(rdr.GetOrdinal("patientID")),
                        VisitID = rdr.GetInt32(rdr.GetOrdinal("visitID")),
                        Name = rdr.GetString(rdr.GetOrdinal("patientName")),
                        PatientEmail = rdr.IsDBNull(rdr.GetOrdinal("patientEmail")) ? "" : rdr.GetString(rdr.GetOrdinal("patientEmail")),
                        Description = rdr.IsDBNull(rdr.GetOrdinal("patientDescription")) ? "" : rdr.GetString(rdr.GetOrdinal("patientDescription"))
                    });
                }
            }
            return result;
        }

        public async Task<IEnumerable<Doctor>> ExecuteDoctorReadCommand(SqlCommand command)
        {
            var result = new List<Doctor>();
            using (var conn = await createConnectionAsync())
            {
                command.Connection = conn;
                using var rdr = await command.ExecuteReaderAsync();
                while (await rdr.ReadAsync())
                {
                    result.Add(new Doctor
                    {
                        Id = rdr.GetInt32(rdr.GetOrdinal("doctorID")),
                        VisitID = rdr.IsDBNull(rdr.GetOrdinal("visitID")) ? 0 : rdr.GetInt32(rdr.GetOrdinal("visitID")),
                        Name = rdr.GetString(rdr.GetOrdinal("doctorName")),
                        Email = rdr.IsDBNull(rdr.GetOrdinal("doctorEmail")) ? "" : rdr.GetString(rdr.GetOrdinal("doctorEmail")),
                        Phone = rdr.IsDBNull(rdr.GetOrdinal("doctorPhone")) ? "" : rdr.GetString(rdr.GetOrdinal("doctorPhone")),
                        Specialization = rdr.IsDBNull(rdr.GetOrdinal("specialization")) ? "" : rdr.GetString(rdr.GetOrdinal("specialization"))
                    });
                }
            }
            return result;
        }

        public async Task ExecuteWriteCommand(SqlCommand command)
        {
            using var conn = await createConnectionAsync();
            command.Connection = conn;
            await command.ExecuteNonQueryAsync();
        }
    }
}